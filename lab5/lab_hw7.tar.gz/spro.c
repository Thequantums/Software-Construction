#include <stdio.h>
#include <math.h>


int main() {

double num = cos(sqrt(3.0));

printf("%.17g",num);

return 0;
}
